# Bank Simulation in Java

## Description
This project simulates basic bank operations (deposit, withdrawal, balance check) using Java OOP principles.

## How to Run
1. Compile: `javac Account.java BankSimulation.java`
2. Run: `java BankSimulation`

## Features
- Deposit/withdraw money
- View transaction history
- Error handling for insufficient balance