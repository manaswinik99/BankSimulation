import java.util.ArrayList;

public class Account {
    private String accountHolderName;
    private double balance;
    private ArrayList<String> transactionHistory;

    public Account(String name, double initialBalance) {
        this.accountHolderName = name;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
        transactionHistory.add("Account opened with balance: $" + initialBalance);
    }

    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited: $" + amount);
    }

    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient funds!");
            transactionHistory.add("Failed withdrawal attempt: $" + amount);
        } else {
            balance -= amount;
            transactionHistory.add("Withdrew: $" + amount);
        }
    }

    public double getBalance() {
        return balance;
    }

    public void printTransactionHistory() {
        System.out.println("Transaction History:");
        for (String txn : transactionHistory) {
            System.out.println(txn);
        }
    }
}